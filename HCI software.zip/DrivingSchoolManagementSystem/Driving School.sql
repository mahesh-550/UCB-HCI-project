CREATE SCHEMA drivingschoolmanagementsystem;

CREATE TABLE drivingschoolmanagementsystem.admin (
  `AID` int NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `phone` int DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`AID`)
);

CREATE TABLE drivingschoolmanagementsystem.student (
  `sid` int NOT NULL,
  `name` varchar(75) DEFAULT NULL,
  `age` int DEFAULT NULL,
  `address` varchar(75) DEFAULT NULL,
  `phone` int DEFAULT NULL,
  `grade` int DEFAULT NULL,
  `regstatus` varchar(45) DEFAULT NULL,
  `username` varchar(75) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`sid`)
);

CREATE TABLE drivingschoolmanagementsystem.teacher (
  `teacherID` int NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `age` int DEFAULT NULL,
  `nic` varchar(45) DEFAULT NULL,
  `address` varchar(45) DEFAULT NULL,
  `phone` int DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `salary` double DEFAULT NULL,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`teacherID`)
);

CREATE TABLE drivingschoolmanagementsystem.grades (
  `gId` int NOT NULL,
  `garde` varchar(45) DEFAULT NULL,
  `amount` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`gId`)
);

CREATE TABLE drivingschoolmanagementsystem.material (
  `mId` int NOT NULL AUTO_INCREMENT,
  `subjectID` varchar(45) DEFAULT NULL,
  `path` varchar(45) DEFAULT NULL,
  `uploadedBy` int DEFAULT NULL,
  `description` varchar(45) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `subject` varchar(45) DEFAULT NULL,
  `uploadedFile` mediumblob,
  `fileName` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`mId`)
);

CREATE TABLE drivingschoolmanagementsystem.notices (
  `noticeID` int NOT NULL AUTO_INCREMENT,
  `title` varchar(145) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`noticeID`)
);

INSERT INTO `drivingschoolmanagementsystem`.`admin`
(`AID`,
`name`,
`phone`,
`email`,
`username`,
`password`)
VALUES
(1,
'ADMIN',
'123456789',
'admin@gmail.com',
'admin',
'password');

INSERT INTO `drivingschoolmanagementsystem`.`grades`
(`gId`,
`garde`,
`amount`)
VALUES
(1,
'Introductory',
null);

INSERT INTO `drivingschoolmanagementsystem`.`grades`
(`gId`,
`garde`,
`amount`)
VALUES
(2,
'Standard',
null);

INSERT INTO `drivingschoolmanagementsystem`.`grades`
(`gId`,
`garde`,
`amount`)
VALUES
(3,
'Pass',
null);

INSERT INTO `drivingschoolmanagementsystem`.`material`
(`mId`,
`subjectID`,
`path`,
`uploadedBy`,
`description`,
`title`,
`subject`,
`uploadedFile`,
`fileName`)
VALUES
(1,
NULL,
NULL,
NULL,
'Lesson 1',
'Lesson 1',
'Lesson 1',
NULL,
NULL);

INSERT INTO `drivingschoolmanagementsystem`.`material`
(`mId`,
`subjectID`,
`path`,
`uploadedBy`,
`description`,
`title`,
`subject`,
`uploadedFile`,
`fileName`)
VALUES
(2,
NULL,
NULL,
NULL,
'Lesson 2',
'Lesson 2',
'Lesson 2',
NULL,
NULL);

INSERT INTO `drivingschoolmanagementsystem`.`material`
(`mId`,
`subjectID`,
`path`,
`uploadedBy`,
`description`,
`title`,
`subject`,
`uploadedFile`,
`fileName`)
VALUES
(3,
NULL,
NULL,
NULL,
'Lesson 3',
'Lesson 3',
'Lesson 3',
NULL,
NULL);

INSERT INTO `drivingschoolmanagementsystem`.`teacher`
(`teacherID`,
`name`,
`address`,
`phone`,
`email`)
VALUES
(1,
'Teacher1',
'Teacher1 addd',
'1234567891',
'teacher1@gmail.com');

INSERT INTO `drivingschoolmanagementsystem`.`teacher`
(`teacherID`,
`name`,
`address`,
`phone`,
`email`)
VALUES
(2,
'Teacher2',
'Teacher2 addd',
'1234567891',
'teacher2@gmail.com');

INSERT INTO `drivingschoolmanagementsystem`.`student`
(`sid`,
`name`,
`age`,
`address`,
`phone`,
`grade`,
`regstatus`,
`username`,
`password`,
`teacherID`)
VALUES
(1,
'Robin',
25,
'Birmingham',
'34213567',
8,
'Registered',
'robin',
'robin123',
2);

INSERT INTO `drivingschoolmanagementsystem`.`student`
(`sid`,
`name`,
`age`,
`address`,
`phone`,
`grade`,
`regstatus`,
`username`,
`password`,
`teacherID`)
VALUES
(2,
'Student1',
30,
'Atudent1 Addess',
'123456789',
1,
'Registered',
'student1',
'password1',
1);