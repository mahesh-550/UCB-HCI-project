package com.school;

import java.io.InputStream;

public class FileDownload {
	private int mId;
	private InputStream inputStream;
	private String fileName;
	
	
	public int getmId() {
		return mId;
	}
	public void setmId(int mId) {
		this.mId = mId;
	}
	public InputStream getInputStream() {
		return inputStream;
	}
	public void setInputStream(InputStream inputStream) {
		this.inputStream = inputStream;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	public FileDownload(int mId, InputStream inputStream, String fileName) {
		super();
		this.mId = mId;
		this.inputStream = inputStream;
		this.fileName = fileName;
	}
	public FileDownload() {
		// TODO Auto-generated constructor stub
	}
}
