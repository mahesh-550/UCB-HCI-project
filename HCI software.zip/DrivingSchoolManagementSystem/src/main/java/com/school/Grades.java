package com.school;

public class Grades {
	private int grade;
	private int amount;
	
	public Grades(int grade, int amount) {
		this.grade = grade;
		this.amount = amount;
	}

	public int getGrade() {
		return grade;
	}

	public int getAmount() {
		return amount;
	}

}
