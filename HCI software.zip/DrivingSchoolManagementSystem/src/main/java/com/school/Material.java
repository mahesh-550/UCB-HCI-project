package com.school;

public class Material {
	private int mId;
	public int getmId() {
		return mId;
	}

	public void setmId(int mId) {
		this.mId = mId;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	private String title;
	private String subject;
	private String desc;
	
	
	public Material(int mId, String title,String subject, String desc) {
		this.mId = mId;
		this.title = title;
		this.setSubject(subject);
		this.desc = desc;
	}

	public int getMId() {
		return mId;
	}

	public String getTitle() {
		return title;
	}

	public String getDesc() {
		return desc;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}
	

}
