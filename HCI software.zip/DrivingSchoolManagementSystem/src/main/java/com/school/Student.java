package com.school;

public class Student extends User{
	private int sid;
	private int grade;
	private String regstatus;
	private String gradeName;
	private String teacherName;
	
	public Student(int sid, String name, int age, String address, int phone, int grade, String username, String password, String regstatus, String gradeName, String teacherName) {
		super(name, age, address, phone, username, password);
		
		this.grade = grade;
		this.sid = sid;
		this.regstatus = regstatus;
		this.gradeName = gradeName;
		this.teacherName = teacherName;
	}

	public int getSid() {
		return sid;
	}

	public int getGrade() {
		return grade;
	}

	public String getRegstatus() {
		return regstatus;
	}

	public String getGradeName() {
		return gradeName;
	}

	public String getTeacherName() {
		return teacherName;
	}

}