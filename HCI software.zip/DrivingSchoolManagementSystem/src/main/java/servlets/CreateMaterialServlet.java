package servlets;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.school.Material;
import com.school.schoolDBUtil;

/**
 * Servlet implementation class CreateNoticeServlet
 */
@WebServlet("/CreateMaterialServlet")
@MultipartConfig(maxFileSize = 16177215) 
public class CreateMaterialServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
		String title = request.getParameter("title");
		String desc = request.getParameter("desc");
		String subject = request.getParameter("subject");
		InputStream inputStream = null;
		 Part filePart = request.getPart("photo");
		 if (filePart != null) {
	            // prints out some information for debugging
	            System.out.println(filePart.getContentType());
	            System.out.println(filePart.getHeaderNames());
	            System.out.println(filePart.getName());
	            System.out.println(filePart.getContentType());
	             
	            // obtains input stream of the upload file
	            inputStream = filePart.getInputStream();
	        }
		 
		
		boolean isTrue = schoolDBUtil.addStudyMaterial(title, desc, subject, inputStream);
		
		if(isTrue == true) {
			List<Material> materialDetails = schoolDBUtil.viewMaterial();
			request.setAttribute("materialDetails", materialDetails);
			
			RequestDispatcher dis = request.getRequestDispatcher("StudyMaterialUI.jsp");
			dis.forward(request, response);
		}
		else {
			out.println("<script type = 'text/javascript'>");
			out.println("alert('Incorrect Details');");
			out.println("location = 'CreateStudyMaterialUI.jsp'");
			out.println("</script>");
		}
	}

}
