package servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.school.Material;
import com.school.Notice;
import com.school.schoolDBUtil;

/**
 * Servlet implementation class NoticeServlet
 */
@WebServlet("/ViewMaterialServlet")
public class ViewMaterialServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			List<Material> materialDetails = schoolDBUtil.viewMaterial();
			request.setAttribute("materialDetails", materialDetails);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		RequestDispatcher dis = request.getRequestDispatcher("StudyMaterialUI.jsp");
		dis.forward(request, response);
	}

}
