package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.school.Admin;
import com.school.Principle;
import com.school.schoolDBUtil;

@WebServlet("/createTeacherAccount")
public class createTeacherAccount extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
		String adminUname = request.getParameter("adminUname");
		String name = request.getParameter("name");
		String address = request.getParameter("address");
		int phone = Integer.parseInt(request.getParameter("phone"));
		String email = request.getParameter("email");
		
		boolean isTrue;
		
		isTrue = schoolDBUtil.createteacheraccount(name, address,  phone,  email);
		
		if(isTrue == true) {
			RequestDispatcher dis = request.getRequestDispatcher("AdminUI.jsp");
			dis.forward(request, response);
		} else {
			out.println("<script type = 'text/javascript'>");
			out.println("alert('Incorrect Details');");
			out.println("location = 'createTeacherAccount.jsp'");
			out.println("</script>");
		}
	}

}
